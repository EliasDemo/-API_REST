void main() {
  Calculadora calc = Calculadora();
  print('Suma: ${calc.suma(10, 5)}');
  print('resta: ${calc.resta(5, 2)}');
  print('multiplicacion: ${calc.multiplicacion(2, 2)}');
  print('division: ${calc.division(10, 2)}');

}


abstract class Operacion {
  double suma(double a, double b);
  double resta(double a, double b);
  double multiplicacion(double a, double b);
  double division(double a, double b);
}


class Calculadora extends Operacion{
  @override
  double suma(double a, double b) {
    return a +b;
  }
  @override
  double resta(double a, double b){
    return a - b;
  }
  @override
  double multiplicacion(double a, double b){
    return a* b;

  }
  @override
  double division(double a, double b) {
    return a / b;
  }
}
