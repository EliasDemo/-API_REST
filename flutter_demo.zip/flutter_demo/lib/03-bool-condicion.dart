
void main() {
  bool? isActive=false;

  if (isActive == null) {
    print('isActive es null');
  } else {
    print('No es null');
  }

}