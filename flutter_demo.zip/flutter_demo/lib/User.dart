import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class User {
  late int iD;
  late final String nombre;
  late final String apellidos;
  late final int dni;

  User(
      {required this.iD,
        required this.nombre,
        required this.apellidos,
        required this.dni,
        });
  User.fromJson(Map<String, dynamic> json){
    iD = json['ID'];
    nombre = json['NOMBRE'];
    apellidos = json['APELLIDOS'];
    dni: json['DNI'];

  }
  factory User.fromJsonModelo(Map<String, dynamic> json) {
    return User(
      iD: json['ID'],
      nombre: json['NOMBRE'],
      apellidos: json['APELLIDOS'],
      dni: json['DNI'],

    );
  }
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['ID'] = this.iD;
    data['NOMBRE'] = this.nombre;
    data['APELLIDOS'] = this.apellidos;
    data['DNI'] = this.dni;

    return data;
  }
}