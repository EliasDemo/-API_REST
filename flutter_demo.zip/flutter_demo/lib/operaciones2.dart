void main() {
  Calculadora calc = Calculadora();
  print('Suma: ${calc.sumar(10, 5)}');
  print('resta: ${calc.restar(5, 2)}');
  print('multiplicacion: ${calc.multiplicacion(2, 2)}');
  print('division: ${calc.division(10, 2)}');

}

class Operaciones{
  double sumar(double a, double b){
    return a+b;
  }
  double restar(double a, double b){
    return a-b;
  }double multiplicacion(double a, double b){
    return a*b;
  }
  double division(double a, double b){
    return a/b;
  }

}

class Calculadora extends Operaciones{
  @override
  double sumar(double a, double b) {
    // TODO: implement sumar
    return super.sumar(a, b);
  }
  @override
  double restar(double a, double b) {
    // TODO: implement restar
    return super.restar(a, b);
  }
  @override
  double multiplicacion(double a, double b) {
    // TODO: implement multiplicacion
    return super.multiplicacion(a, b);
  }
  @override
  double division(double a, double b) {
    // TODO: implement division
    return super.division(a, b);
  }
}